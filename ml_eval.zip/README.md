# Ssense: Research Paper Evaluation Archive (`ml_eval.zip`)

This archive contains **all empirical evaluations, benchmark datasets, high-resolution figures (300 DPI PNG & Vector SVG), publication-ready LaTeX tables, statutory decision trees, and reproduction test runners** specifically organized to directly add, verify, and cite in the IEEE research paper:

**"Ssense: A Domain-Adapted Legal Small Language Model and Scalable Inference Architecture for Auditing Global Web Compliance under India's DPDP Act, 2023 and DPDP Rules, 2025"**

---

## Archive Structure

```
ml_eval/
├── paper_eval_sections/                  # Paper Drafts, Evaluation Matrices & LaTeX Tables
│   ├── ssense_paper_eval_section.md      # Direct extraction of Section VII & Section VIII
│   ├── LATEX_TABLES_READY.tex            # Ready-to-paste IEEE LaTeX source tables (Tables I-VI)
│   ├── eval_final.md                     # Comprehensive evaluation matrix & benchmark tables
│   ├── EVALUATION_REPORT.md              # 16 KB exhaustive industrial evaluation report
│   ├── METHODOLOGY.md                    # Double-blind advocate review rubric & experimental protocol
│   ├── Evaluation.md                     # Core evaluation definitions & methodology
│   └── ssense_equations.md               # Formal deontic mathematical formulations & loss equations
│
├── figures/                              # Publication-Grade Figures (PNG & Vector SVG)
│   ├── png_300dpi/                       # 300 DPI raster figures for camera-ready submission
│   │   ├── fig5_deontic_confusion_matrix.png
│   │   ├── fig6_statutory_taxonomy_f1_breakdown.png
│   │   ├── fig7_comparative_radar_benchmark.png
│   │   ├── fig8_judge_vs_human_reliability.png
│   │   ├── fig9_omission_firewall_ablation.png
│   │   ├── fig10_fiduciary_audit_landscape.png
│   │   ├── fig11_readability_and_cognitive_lift.png
│   │   ├── fig12_adversarial_trap_resistance.png
│   │   ├── fig14_apliance_head_to_head_replication.png
│   │   ├── fig15_multilabel_legalbench_f1_mcc.png
│   │   ├── fig16_sovereign_edge_hardware_profile.png
│   │   ├── fig21_dpdp_vs_gdpr_jurisdiction_isolation.png
│   │   ├── fig22_live_audit_case_study_breakdown.png
│   │   ├── fig23_system_throughput_and_scaling.png
│   │   └── fig25_best_performing_fiduciaries_dpdp_benchmark.png
│   │
│   └── vector_svg/                       # Infinite-resolution vector graphics for PDF compilation
│       └── [All matching .svg files]
│
├── eval_data/                            # Raw Ground Truth, Holdouts, and Benchmark Datasets
│   ├── evaluation_results_comprehensive.json # Master benchmark scorecard across all baselines
│   ├── eval_metrics.csv                  # Tabular metrics for automated spreadsheet analysis
│   ├── master_evaluation_scorecard.json # Quantitative scorecard across 18 certification axes
│   ├── apliance_replication_report.json  # 400-instance APLiance head-to-head replication results
│   ├── ground_truth.json                 # 61 holdout corporate policies with 95 ground-truth labels
│   ├── security_adversarial_suite.json   # 500 KB comprehensive red-team adversarial suite
│   ├── dpdp_chatbot_qa.json              # Interactive citizen legal consultation benchmark
│   ├── dpdp_rag_testset.json             # Statutory chunk retrieval grounding test queries
│   ├── redteam_hallucination_prompts.json# Confabulation and fake safe-harbor probe suite
│   ├── audit_10sites_results.json        # Real-world fiduciary compliance audit outputs
│   ├── chat_10sites_results.json         # Real-world streaming copilot consultation outputs
│   ├── chat_modes_benchmark.json         # Operating mode latency & quality benchmarks
│   └── manual_audit_verification_10sites.json # Double-blind human advocate validation annotations
│
├── eval_runners/                         # Autonomous Evaluation Test Runners (ml/evals)
│   ├── run_accuracy_evals.py             # Statutory accuracy & multi-label F1 runner
│   ├── run_apliance_benchmark.py         # 400-clause APLiance replication runner
│   ├── run_security_evals.py             # Adversarial injection & sycophancy runner
│   ├── run_hallucination_benchmark.py    # Safe-harbor confabulation & probe runner
│   ├── run_chatbot_evals.py              # Citizen legal dialogue evaluation runner
│   ├── run_grammar_evals.py              # Pushdown Automaton CFG schema decoding runner
│   ├── benchmark_latency.py              # Sovereign edge inference & VRAM profiling runner
│   ├── evaluate_rag.py                   # Statutory RAG retrieval precision/recall runner
│   ├── compare_sota_models.py            # Comparative baseline benchmark runner
│   └── metrics.py, stats.py, verify.py   # Statistical significance & evaluation metrics
│
├── statutory_schemas/                    # Computational Representation of Indian Privacy Law
│   ├── dpdp_act_tree.json                # 26-node formal statutory decision tree (DPDP 2023 & Rules 2025)
│   ├── dpdp_schema.json                  # Formal JSON schema enforcing Pushdown Automaton CFG decoding
│   └── dpdp_index.json                   # Curated legislative chunk index for hybrid RAG grounding
│
└── figure_generation_scripts/            # Autonomous 300 DPI Figure Generation Scripts
    ├── generate_paper_eval_figures.py    # Generates Fig 14 (APLiance), Fig 15 (LegalBench), Fig 16 (Edge)
    ├── generate_additional_paper_figures.py # Generates Fig 21 (Jurisdiction), Fig 22 (Cases), Fig 23 (Serving)
    └── generate_extension_history_figure.py # Generates Fig 24 (History/Pipeline) & Fig 25 (Best Sites)
```

---

## How to Integrate into the IEEE Research Paper

1. **Section Text**: Use `paper_eval_sections/ssense_paper_eval_section.md` which contains the complete manuscript text for **Section VII (Empirical Evaluation Framework)** and **Section VIII (Results and Empirical Discussion)**.
2. **Tables**: Copy and paste the LaTeX table snippets from `paper_eval_sections/LATEX_TABLES_READY.tex` directly into your `.tex` file.
3. **Figures**: Use the high-resolution vector files from `figures/vector_svg/` (`\includegraphics[width=\linewidth]{fig...}`) for crystal-clear vector rendering in IEEE 2-column format.
4. **Data Verification**: Inspect `eval_data/evaluation_results_comprehensive.json` and `eval_data/ground_truth.json` to verify any numerical metric cited in the paper.

---
*Created by Ssense Development Team — Domain-Adapted Legal Small Language Model.*
