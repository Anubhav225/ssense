# Ssense: Complete IEEE Submission & Evaluation Archive (`ssense_final_paperieee.zip`)

This archive contains the complete research paper, all 300 DPI high-resolution figures (PNG & SVG vector), empirical evaluation datasets, statutory deontic schemas, and reproduction scripts for:

**"Ssense: A Domain-Adapted Legal Small Language Model and Scalable Inference Architecture for Auditing Global Web Compliance under India's DPDP Act, 2023 and DPDP Rules, 2025"**  
*Authors: Anubhav Das & Priyanshu Roy*  
*Department of Computer Science and Engineering, Institute of Engineering and Management, Kolkata, India*

---

## Archive Structure

```
ssense_final_paperieee/
├── paper/
│   ├── ssense_paper.md                     # Full IEEE Research Paper (Complete Publication Draft)
│   ├── METHODOLOGY.md                      # Detailed Experimental Protocol & Double-Blind Rubric
│   ├── ssense_equations.md                 # Formal Mathematical Equations & Deontic Logic
│   └── eval_final.md                       # Comprehensive Evaluation Matrix & Benchmark Tables
│
├── figures/                                # High-Resolution 300 DPI & Vector Figures
│   ├── fig1_overall_architecture.png       # Fig 1: End-to-End System Architecture
│   ├── fig2_training_alignment_pipeline.png# Fig 2: Data Forge Synthesis, rsLoRA & SimPO Alignment
│   ├── fig3_three_step_deductive_chain.png # Fig 3: 3-Step Syllogistic Chain & Omission Firewall
│   ├── fig4_audit_request_cache_pipeline.png# Fig 4: Multi-Tier Cache Hierarchy (LRU, SQLite, Mutex)
│   ├── fig4B_throughput_scaling.png        # Fig 4B: PagedAttention Throughput & Speculative Decoding
│   ├── fig5_deontic_confusion_matrix.png/.svg # Fig 5: 4x4 Deontic Modality Confusion Matrix (96.1%)
│   ├── fig6_statutory_taxonomy_f1.png/.svg # Fig 6: Per-Provision Statutory Classification Breakdown
│   ├── fig6B_fiduciary_breakdown.png/.svg  # Fig 6B: Fiduciary Compliance Profiles Across Strategic Sites
│   ├── fig7_comparative_radar.png/.svg     # Fig 7: 8-Axis Sovereign Legal-AI Benchmark Radar
│   ├── fig7A_apliance_replication.png/.svg # Fig 7A / Fig 14: Direct APLiance Replication (N=400)
│   ├── fig7B_multilabel_legalbench.png/.svg# Fig 7B / Fig 15: Multi-Label DPDP-Bench F1 & MCC
│   ├── fig8_judge_vs_human.png/.svg        # Fig 8 / Fig 11: LLM-as-a-Judge Calibration (MAE 0.312)
│   ├── fig8B_jurisdiction_isolation.png/.svg# Fig 8B / Fig 21: Cross-Jurisdictional Bleed (0.0% vs 54%)
│   ├── fig9_omission_ablation.png/.svg     # Fig 9 / Fig 10: Omission Firewall Silence Discrimination
│   ├── fig10_fiduciary_landscape.png/.svg  # Fig 10 / Fig 6: Empirical Audit Scores (>500M MAU)
│   ├── fig11_readability_lift.png/.svg     # Fig 11 / Fig 12: Readability Enhancement (+44 pts FRE)
│   ├── fig12_adversarial_security.png/.svg # Fig 12 / Fig 13: Adversarial Security Resilience (97.9%)
│   ├── fig13B_sovereign_edge.png/.svg      # Fig 13B / Fig 16: Measured Workstation Profile (RTX 3060)
│   ├── fig17_extension_multipanel_live.png # Fig 13C: Live Browser Extension & Sovereign Client UI
│   ├── fig24_extension_audit_pipeline_history.png/.svg # Fig 13D / Fig 24: Extension Audit Pipeline History & Portfolio
│   ├── fig25_best_performing_fiduciaries_dpdp_benchmark.png/.svg # Fig 13E / Fig 25: Statutory Benchmark of Best-Performing Sites
│   ├── ssense_extension_walkthrough.webp   # Public Release Animated Walkthrough Video (WebP)
│   └── ssense_extension_walkthrough.gif    # Public Release High-Res Animated Walkthrough (GIF)
│
├── eval_data/                              # Empirical Benchmarks, Holdouts, and Raw Ground Truth
│   ├── evaluation_results_comprehensive.json # Master benchmark metrics across all baselines
│   ├── eval_metrics.csv                    # Tabular metrics for paper tables
│   ├── EVALUATION_REPORT.md                # Exhaustive industrial evaluation report
│   ├── master_evaluation_scorecard.json   # Master evaluation scorecard & rubric
│   ├── apliance_replication_report.json    # 400-instance APLiance head-to-head replication data
│   ├── ground_truth.json                   # 61 holdout corporate policies with 95 ground-truth labels
│   ├── security_adversarial_suite.json     # Adversarial injection, sycophancy, & 2D-NIAH test suite (500KB)
│   ├── dpdp_chatbot_qa.json                # Interactive citizen legal dialogue evaluation set
│   ├── dpdp_rag_testset.json               # Statutory retrieval grounding test queries
│   ├── redteam_hallucination_prompts.json  # Confabulation and fake safe-harbor probe suite
│   ├── audit_10sites_results.json          # Real-world fiduciary compliance audit outputs
│   ├── chat_10sites_results.json           # Real-world legal consultation chat outputs
│   ├── chat_modes_benchmark.json           # Fast vs Rigorous vs Comprehensive performance benchmarks
│   ├── manual_audit_verification_10sites.json # Double-blind human advocate validation annotations
│   └── Evaluation.md                       # Comprehensive evaluation methodology and results
│
├── eval_runners/                           # Autonomous Evaluation Test Runners (ml/evals)
│   ├── run_apliance_benchmark.py           # APLiance replication benchmark runner
│   ├── run_accuracy_evals.py               # Statutory accuracy & multi-label evaluation runner
│   ├── run_security_evals.py               # Adversarial defense & prompt injection testing runner
│   ├── run_hallucination_benchmark.py      # Safe-harbor confabulation & probe benchmark runner
│   ├── run_chatbot_evals.py                # Citizen legal consultation dialogue evaluation runner
│   ├── run_grammar_evals.py                # CFG pushdown automaton grammar decoding test runner
│   ├── benchmark_latency.py                # Sovereign edge inference & memory profiling runner
│   ├── evaluate_rag.py                     # Statutory RAG retrieval grounding evaluation runner
│   └── metrics.py, stats.py, verify.py     # Deontic metrics and statistical verification utilities
│
├── statutory_schemas/                      # Formal Computational Representation of Indian Law
│   ├── dpdp_act_tree.json                  # 26-node formal statutory decision tree (DPDP 2023 & Rules 2025)
│   ├── dpdp_schema.json                    # Formal JSON schema enforcing Pushdown Automaton CFG decoding
│   └── dpdp_index.json                     # Curated legislative chunk index for hybrid RAG grounding
│
└── scripts/                                # Autonomous Evaluation & Figure Reproduction Scripts
    ├── generate_paper_eval_figures.py      # Generates Fig 14 (APLiance), Fig 15 (LegalBench), Fig 16 (Edge)
    ├── generate_additional_paper_figures.py# Generates Fig 21 (Jurisdiction), Fig 22 (Cases), Fig 23 (Serving)
    ├── generate_extension_figures_and_walkthrough.py # Generates live multi-panel UI figure & animations
    ├── generate_extension_history_figure.py# Generates Fig 24 (Audit Pipeline History) & Fig 25 (Best Fiduciaries)
    └── test_single_chat.py                 # Live HMAC-SHA256 authenticated streaming test client
```

---

## Reproduction Instructions

### 1. Re-generate All Paper Figures
```bash
python scripts/generate_paper_eval_figures.py
python scripts/generate_additional_paper_figures.py
python scripts/generate_extension_figures_and_walkthrough.py
python scripts/generate_extension_history_figure.py
```

### 2. Verify Sovereign SLM Inference on NVIDIA RTX 3060 (12GB)
```bash
python scripts/test_single_chat.py
```

